
</div>

<footer>
    <div class="container">
      <div class="row">
          <div class="col-sm-8">
              <a href="http://www.ydop.com/" style="text-decoration: none;">YDOP</a> <br>
              <a href="https://www.google.com/maps/dir//YDOP,+127+E+Orange+St,+Lancaster,+PA+17602/@40.039978,-76.3050447,17z/" style="text-decoration: none;">127 East Orange Street <br>
              Lancaster, PA 17602</a> (<a href="https://www.google.com/maps/dir//YDOP,+127+E+Orange+St,+Lancaster,+PA+17602/@40.039978,-76.3050447,17z/">Get Directions »</a>)<br>
              <a href="tel:7173971212" style="text-decoration:none;">717-397-1212</a> &nbsp;|&nbsp; <a href="mailto:contact@ydop.com">contact@ydop.com</a>
              <br><small>© 2015</small>
          </div>
          <div class="col-sm-4 text-right">
            <p>
              <a href="/about/">About</a>&nbsp;|&nbsp;
              <a href="/blog/">Blog</a>&nbsp;|&nbsp;
              <a href="/contact/">Contact</a>
            </p>
            <a href="https://plus.google.com/+Ydopmarketing/about" target="_blank"><i class="fa fa-2x fa-google-plus-square"></i></a>&nbsp;
            <a href="https://www.facebook.com/ydopmarketing" target="_blank"><i class="fa fa-2x fa-facebook-square"></i></a>&nbsp;
            <a href="https://twitter.com/ydop" target="_blank"><i class="fa fa-2x fa-twitter-square"></i></a>
          </div>
      </div>
    </div>
  </footer>



<!-- end main container -->

<?php wp_footer(); ?>
</body>
</html>